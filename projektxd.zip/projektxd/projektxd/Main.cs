using Calculator;
using feladatok;
namespace projektxd
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void projekt1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            szamologep sz = new szamologep();
            sz.MdiParent = this;
            sz.Show();
        }

        private void projekt2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.MdiParent = this;
            f.Show();
        }
    }
}
