namespace feladatok
{
    public partial class Form1 : Form
    {

        int red = 0;
        int blue = 0;
        int green = 0;

        public Form1()
        {
            InitializeComponent();

            RedBar.Minimum = 0;
            GreenBar.Minimum = 0;
            BlueBar.Minimum = 0;

            RedBar.Maximum = 255;
            GreenBar.Maximum = 255;
            BlueBar.Maximum = 255;

        }

        private void RedBar_Scroll(object sender, EventArgs e)
        {
            red = RedBar.Value;
            RedLabel.Text = Convert.ToString(RedBar.Value);
            SetColor(red, green, blue);
        }

        private void BlueBar_Scroll(object sender, EventArgs e)
        {
            blue = BlueBar.Value;
            BlueLabel.Text = Convert.ToString(BlueBar.Value);
            SetColor(red, green, blue);
        }

        private void GreenBar_Scroll(object sender, EventArgs e)
        {
            green = GreenBar.Value;
            GreenLabel.Text = Convert.ToString(GreenBar.Value);
            SetColor(red, green, blue);
        }

        private void SetColor(int r, int g, int b)
        {
            Color colorRGB = new Color();
            colorRGB = Color.FromArgb(r, g, b);
            pictureBox1.BackColor = colorRGB;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
