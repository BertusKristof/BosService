﻿namespace feladatok
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            RedBar = new TrackBar();
            BlueBar = new TrackBar();
            GreenBar = new TrackBar();
            pictureBox1 = new PictureBox();
            RedLabel = new Label();
            label1 = new Label();
            BlueLabel = new Label();
            GreenLabel = new Label();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)RedBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BlueBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)GreenBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // RedBar
            // 
            RedBar.Location = new Point(116, 438);
            RedBar.Name = "RedBar";
            RedBar.Size = new Size(480, 45);
            RedBar.TabIndex = 1;
            RedBar.Scroll += RedBar_Scroll;
            // 
            // BlueBar
            // 
            BlueBar.Location = new Point(116, 489);
            BlueBar.Name = "BlueBar";
            BlueBar.Size = new Size(480, 45);
            BlueBar.TabIndex = 2;
            BlueBar.Scroll += BlueBar_Scroll;
            // 
            // GreenBar
            // 
            GreenBar.Location = new Point(116, 540);
            GreenBar.Name = "GreenBar";
            GreenBar.Size = new Size(480, 45);
            GreenBar.TabIndex = 3;
            GreenBar.Scroll += GreenBar_Scroll;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.Location = new Point(231, 90);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(277, 242);
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // RedLabel
            // 
            RedLabel.BorderStyle = BorderStyle.FixedSingle;
            RedLabel.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 238);
            RedLabel.Location = new Point(611, 433);
            RedLabel.Name = "RedLabel";
            RedLabel.Size = new Size(73, 33);
            RedLabel.TabIndex = 9;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 238);
            label1.Location = new Point(43, 438);
            label1.Name = "label1";
            label1.Size = new Size(67, 28);
            label1.TabIndex = 4;
            label1.Text = "Piros:";
            // 
            // BlueLabel
            // 
            BlueLabel.BorderStyle = BorderStyle.FixedSingle;
            BlueLabel.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 238);
            BlueLabel.Location = new Point(611, 489);
            BlueLabel.Name = "BlueLabel";
            BlueLabel.Size = new Size(73, 33);
            BlueLabel.TabIndex = 10;
            // 
            // GreenLabel
            // 
            GreenLabel.BorderStyle = BorderStyle.FixedSingle;
            GreenLabel.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 238);
            GreenLabel.Location = new Point(611, 535);
            GreenLabel.Name = "GreenLabel";
            GreenLabel.Size = new Size(73, 33);
            GreenLabel.TabIndex = 11;
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 238);
            label2.Location = new Point(43, 490);
            label2.Name = "label2";
            label2.Size = new Size(67, 28);
            label2.TabIndex = 12;
            label2.Text = "Kék:";
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 238);
            label3.Location = new Point(43, 540);
            label3.Name = "label3";
            label3.Size = new Size(67, 28);
            label3.TabIndex = 13;
            label3.Text = "Zöld:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(721, 634);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(GreenLabel);
            Controls.Add(BlueLabel);
            Controls.Add(RedLabel);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(GreenBar);
            Controls.Add(BlueBar);
            Controls.Add(RedBar);
            Name = "Form1";
            Text = "RGB";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)RedBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)BlueBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)GreenBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TrackBar RedBar;
        private TrackBar BlueBar;
        private TrackBar GreenBar;
        private PictureBox pictureBox1;
        private Label RedLabel;
        private Label label1;
        private Label BlueLabel;
        private Label GreenLabel;
        private Label label4;
        private Label label2;
        private Label label3;
    }
}
