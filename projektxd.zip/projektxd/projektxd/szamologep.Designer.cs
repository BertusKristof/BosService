﻿namespace Calculator
{
    partial class szamologep
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TxtBox = new TextBox();
            SevenBtn = new Button();
            FourBtn = new Button();
            OneBtn = new Button();
            ZeroBtn = new Button();
            ClearBtn = new Button();
            TwoBtn = new Button();
            FiveBtn = new Button();
            EightBtn = new Button();
            EqualBtn = new Button();
            ThreeBtn = new Button();
            SixBtn = new Button();
            NineBtn = new Button();
            DevideBtn = new Button();
            MultiplyBtn = new Button();
            PlusBtn = new Button();
            MinusBtn = new Button();
            SuspendLayout();
            // 
            // TxtBox
            // 
            TxtBox.Font = new Font("Segoe UI", 20F);
            TxtBox.Location = new Point(27, 12);
            TxtBox.Name = "TxtBox";
            TxtBox.Size = new Size(355, 43);
            TxtBox.TabIndex = 0;
            TxtBox.Text = "0";
            TxtBox.TextAlign = HorizontalAlignment.Right;
            // 
            // SevenBtn
            // 
            SevenBtn.Font = new Font("Segoe UI", 17F);
            SevenBtn.Location = new Point(27, 74);
            SevenBtn.Name = "SevenBtn";
            SevenBtn.Size = new Size(75, 73);
            SevenBtn.TabIndex = 1;
            SevenBtn.Text = "7";
            SevenBtn.UseVisualStyleBackColor = true;
            SevenBtn.Click += SevenBtn_Click;
            // 
            // FourBtn
            // 
            FourBtn.Font = new Font("Segoe UI", 17F);
            FourBtn.Location = new Point(27, 166);
            FourBtn.Name = "FourBtn";
            FourBtn.Size = new Size(75, 73);
            FourBtn.TabIndex = 2;
            FourBtn.Text = "4";
            FourBtn.UseVisualStyleBackColor = true;
            FourBtn.Click += FourBtn_Click;
            // 
            // OneBtn
            // 
            OneBtn.Font = new Font("Segoe UI", 17F);
            OneBtn.Location = new Point(27, 258);
            OneBtn.Name = "OneBtn";
            OneBtn.Size = new Size(75, 73);
            OneBtn.TabIndex = 3;
            OneBtn.Text = "1";
            OneBtn.UseVisualStyleBackColor = true;
            OneBtn.Click += OneBtn_Click;
            // 
            // ZeroBtn
            // 
            ZeroBtn.Font = new Font("Segoe UI", 17F);
            ZeroBtn.Location = new Point(27, 350);
            ZeroBtn.Name = "ZeroBtn";
            ZeroBtn.Size = new Size(75, 73);
            ZeroBtn.TabIndex = 4;
            ZeroBtn.Text = "0";
            ZeroBtn.UseVisualStyleBackColor = true;
            ZeroBtn.Click += ZeroBtn_Click;
            // 
            // ClearBtn
            // 
            ClearBtn.Font = new Font("Segoe UI", 17F);
            ClearBtn.Location = new Point(119, 350);
            ClearBtn.Name = "ClearBtn";
            ClearBtn.Size = new Size(75, 73);
            ClearBtn.TabIndex = 8;
            ClearBtn.Text = "C";
            ClearBtn.UseVisualStyleBackColor = true;
            ClearBtn.Click += ClearBtn_Click;
            // 
            // TwoBtn
            // 
            TwoBtn.Font = new Font("Segoe UI", 17F);
            TwoBtn.Location = new Point(119, 258);
            TwoBtn.Name = "TwoBtn";
            TwoBtn.Size = new Size(75, 73);
            TwoBtn.TabIndex = 7;
            TwoBtn.Text = "2";
            TwoBtn.UseVisualStyleBackColor = true;
            TwoBtn.Click += TwoBtn_Click;
            // 
            // FiveBtn
            // 
            FiveBtn.Font = new Font("Segoe UI", 17F);
            FiveBtn.Location = new Point(119, 166);
            FiveBtn.Name = "FiveBtn";
            FiveBtn.Size = new Size(75, 73);
            FiveBtn.TabIndex = 6;
            FiveBtn.Text = "5";
            FiveBtn.UseVisualStyleBackColor = true;
            FiveBtn.Click += FiveBtn_Click;
            // 
            // EightBtn
            // 
            EightBtn.Font = new Font("Segoe UI", 17F);
            EightBtn.Location = new Point(119, 74);
            EightBtn.Name = "EightBtn";
            EightBtn.Size = new Size(75, 73);
            EightBtn.TabIndex = 5;
            EightBtn.Text = "8";
            EightBtn.UseVisualStyleBackColor = true;
            EightBtn.Click += EightBtn_Click;
            // 
            // EqualBtn
            // 
            EqualBtn.Font = new Font("Segoe UI", 17F);
            EqualBtn.Location = new Point(211, 350);
            EqualBtn.Name = "EqualBtn";
            EqualBtn.Size = new Size(75, 73);
            EqualBtn.TabIndex = 12;
            EqualBtn.Text = "=";
            EqualBtn.UseVisualStyleBackColor = true;
            EqualBtn.Click += EqualBtn_Click;
            // 
            // ThreeBtn
            // 
            ThreeBtn.Font = new Font("Segoe UI", 17F);
            ThreeBtn.Location = new Point(211, 258);
            ThreeBtn.Name = "ThreeBtn";
            ThreeBtn.Size = new Size(75, 73);
            ThreeBtn.TabIndex = 11;
            ThreeBtn.Text = "3";
            ThreeBtn.UseVisualStyleBackColor = true;
            ThreeBtn.Click += ThreeBtn_Click;
            // 
            // SixBtn
            // 
            SixBtn.Font = new Font("Segoe UI", 17F);
            SixBtn.Location = new Point(211, 166);
            SixBtn.Name = "SixBtn";
            SixBtn.Size = new Size(75, 73);
            SixBtn.TabIndex = 10;
            SixBtn.Text = "6";
            SixBtn.UseVisualStyleBackColor = true;
            SixBtn.Click += SixBtn_Click;
            // 
            // NineBtn
            // 
            NineBtn.Font = new Font("Segoe UI", 17F);
            NineBtn.Location = new Point(211, 74);
            NineBtn.Name = "NineBtn";
            NineBtn.Size = new Size(75, 73);
            NineBtn.TabIndex = 9;
            NineBtn.Text = "9";
            NineBtn.UseVisualStyleBackColor = true;
            NineBtn.Click += NineBtn_Click;
            // 
            // DevideBtn
            // 
            DevideBtn.Font = new Font("Segoe UI", 17F);
            DevideBtn.Location = new Point(307, 350);
            DevideBtn.Name = "DevideBtn";
            DevideBtn.Size = new Size(75, 73);
            DevideBtn.TabIndex = 16;
            DevideBtn.Text = "/";
            DevideBtn.UseVisualStyleBackColor = true;
            DevideBtn.Click += DevideBtn_Click;
            // 
            // MultiplyBtn
            // 
            MultiplyBtn.Font = new Font("Segoe UI", 17F);
            MultiplyBtn.Location = new Point(307, 258);
            MultiplyBtn.Name = "MultiplyBtn";
            MultiplyBtn.Size = new Size(75, 73);
            MultiplyBtn.TabIndex = 15;
            MultiplyBtn.Text = "*";
            MultiplyBtn.UseVisualStyleBackColor = true;
            MultiplyBtn.Click += MultiplyBtn_Click;
            // 
            // PlusBtn
            // 
            PlusBtn.Font = new Font("Segoe UI", 17F);
            PlusBtn.Location = new Point(307, 166);
            PlusBtn.Name = "PlusBtn";
            PlusBtn.Size = new Size(75, 73);
            PlusBtn.TabIndex = 14;
            PlusBtn.Text = "+";
            PlusBtn.UseVisualStyleBackColor = true;
            PlusBtn.Click += PlusBtn_Click;
            // 
            // MinusBtn
            // 
            MinusBtn.Font = new Font("Segoe UI", 17F);
            MinusBtn.Location = new Point(307, 74);
            MinusBtn.Name = "MinusBtn";
            MinusBtn.Size = new Size(75, 73);
            MinusBtn.TabIndex = 13;
            MinusBtn.Text = "-";
            MinusBtn.UseVisualStyleBackColor = true;
            MinusBtn.Click += MinusBtn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(411, 436);
            Controls.Add(DevideBtn);
            Controls.Add(MultiplyBtn);
            Controls.Add(PlusBtn);
            Controls.Add(MinusBtn);
            Controls.Add(EqualBtn);
            Controls.Add(ThreeBtn);
            Controls.Add(SixBtn);
            Controls.Add(NineBtn);
            Controls.Add(ClearBtn);
            Controls.Add(TwoBtn);
            Controls.Add(FiveBtn);
            Controls.Add(EightBtn);
            Controls.Add(ZeroBtn);
            Controls.Add(OneBtn);
            Controls.Add(FourBtn);
            Controls.Add(SevenBtn);
            Controls.Add(TxtBox);
            Name = "Form1";
            Text = " Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox TxtBox;
        private Button SevenBtn;
        private Button FourBtn;
        private Button OneBtn;
        private Button ZeroBtn;
        private Button ClearBtn;
        private Button TwoBtn;
        private Button FiveBtn;
        private Button EightBtn;
        private Button EqualBtn;
        private Button ThreeBtn;
        private Button SixBtn;
        private Button NineBtn;
        private Button DevideBtn;
        private Button MultiplyBtn;
        private Button PlusBtn;
        private Button MinusBtn;
    }
}
